
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>EasytoSearch</title>
    <!-- Favicon -->
    
    <!-- Animate CSS Link -->
    <link rel="stylesheet" href="./lib/WOW-master/css/libs/animate.css">
    <!-- Font CDN Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alegreya+Sans+SC:ital,wght@0,100;0,300;0,400;0,500;0,700;0,800;0,900;1,100;1,300;1,400;1,500;1,700;1,800;1,900&family=Great+Vibes&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>

    <!-- Header Start -->
    <header class="ets_navbar sticky-top">
        <div class="container">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg px-0" id="ets_main_nav">
                <!-- Logo -->
                
                <a class="navbar-brand" href="./index-02.php"> <img class="img-rounded" src="images/logo.svg" alt="" width="140%"> </a>
                <!-- Logo -->

                <!-- HamBurger -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span><i class="fas fa-bars"></i></span>
                </button>
                <!-- HamBurger -->

                <!-- Nav Item -->
                <div class="collapse navbar-collapse js-clone-nav justify-content-end">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" href="#home">Home <span class="sr-only">(current)</span></a>
                        </li>
                      
                        <li class="nav-item">
                            <a class="nav-link" href="./restaurants.php">Restautants</a>
                        </li>
                     
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./pages/index.php">login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./pages/registration.php">Registration</a>
                        </li>
                    </ul>
                </div>
                <!-- Nav Item -->
            </nav>
            <!-- Navbar -->

            <!-- Tab And Mobile View -->
            <div class="collapse navbar-collapse ets_mobile_view" id="navbarSupportedContent">
                <div class="show_width container">
                    <div class="text-right">
                        <button class="navbar-toggler ets_cross_btn p-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span><i class="fa fa-times"></i></span>
                        </button>
                    </div>
                    
                    <div class="navbar px-0 ets_mobile_view_body"></div>
                </div>
            </div>
            <!-- Tab And Mobile View -->
        </div>
    </header>
    <!-- Header End -->

    <main data-bs-spy="scroll" data-bs-target="#ets_main_nav" class="position-relative">
        <!-- Hero Section Start -->
        <section class="ets_hero_wrapper" id="home">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-md col-lg-6 order-1 order-lg-0 wow fadeInLeft">
                        <h4 class="mb-2">Its Quick & Amusing!</h4>
                        <h1 class="text-white mb-xl-3 mb-lg-2">The Art of speed food Quality</h1>
                       
                        <p class="pe-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit.Varius sed pharetra dictum neque massa congue</p>
                        <a href="#about" class="btn">See Menu</a>
                    </div>
                    <div class="col-md-md col-lg-6 d-flex justify-content-center justify-content-lg-end order-0 order-lg-1 mb-4 mb-md-5 mb-lg-0 wow fadeInRight">
                        
                    </div>
                </div>
            </div>
        </section>
        <!-- Hero Section End -->

        <!-- About Section Start -->
        <section class="ets_about_wrapper" id="about">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-12 col-lg-6 mb-4 mb-md-5 mb-lg-0 wow fadeInLeft">
                        <div class="ets_img_wrapper position-relative">
                            <img src="./assets/images/about_img.png" class="w-100 h-100" alt="About Image">
                            <div class="ets_img_overlay"></div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-6 wow fadeInRight">
                        <h2>We Create the best foody product</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque diam pellentesque bibendum non dui volutpat fringilla bibendum. Urna, elit augue urna, vitae feugiat pretium donec id elementum. Ultrices mattis sed vitae mus risus. Lacus nisi, et ac dapibus sit eu velit in consequat.</p>
                        <ul>
                            <li>
                                <i class="fas fa-check ets_icon"></i>
                                Keep safe exploring the internet
                            </li>
                            <li>
                                <i class="fas fa-check ets_icon"></i>
                                Secure your business and website
                            </li>
                            <li class="mb-4">
                                <i class="fas fa-check ets_icon"></i>
                                Connect to ultra-fast private servers
                            </li>
                        </ul>
                        <a href="#contact" class="btn">Contact me</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- About Section End -->

        <!-- Services Section Start -->
        <section class="ets_services_wrapper" id="services">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-6 offset-md-0 offset-lg-3 wow fadeInUp">
                        <h2 class="text-center text-md-start text-lg-center">Choose Food Iteam</h2>
                        <p class="text-center text-md-start text-lg-center mb-5">I began my works as and engineer and as a freelancer before taking the position of head of designs for locals business in Egypt.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-lg-4 mb-4 wow fadeInDown">
                        <div class="ets_card text-center">
                            <div class="ets_card_child">
                                <div class="ets_card_child_two">
                                    <div class="ets_card_child_three">
                                        <div class="ets_icon_wrapper">
                                            <div class="ets_service_icon">
                                                <i class="fas fa-hamburger"></i>
                                            </div>
                                        </div>
                                        <h6>Fast Food Dish</h6>
                                        <p class="mb-0">Multiple layers of security are dispersed across the computers, networks.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-4 mb-md-0 wow fadeInDown">
                        <div class="ets_card text-center">
                            <div class="ets_card_child">
                                <div class="ets_card_child_two">
                                    <div class="ets_card_child_three">
                                        <div class="ets_icon_wrapper">
                                            <div class="ets_service_icon">
                                                <i class="fas fa-utensils"></i>
                                            </div>
                                        </div>
                                        <h6>Lettuce Leaf</h6>
                                        <p class="mb-0">Continuously monitor network activities to detect and respond to suspicious</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-4 mb-lg-0 wow fadeInDown">
                        <div class="ets_card text-center">
                            <div class="ets_card_child">
                                <div class="ets_card_child_two">
                                    <div class="ets_card_child_three">
                                        <div class="ets_icon_wrapper">
                                            <div class="ets_service_icon">
                                                <i class="fas fa-stroopwafel"></i>
                                            </div>
                                        </div>
                                        <h6>Fresh Breakfast</h6>
                                        <p class="mb-0">For your security secure your data and assets as soon as possible.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-4 mb-md-0 wow fadeInUp">
                        <div class="ets_card text-center">
                            <div class="ets_card_child">
                                <div class="ets_card_child_two">
                                    <div class="ets_card_child_three">
                                        <div class="ets_icon_wrapper">
                                            <div class="ets_service_icon">
                                                <i class="fas fa-pizza-slice"></i>
                                            </div>
                                        </div>
                                        <h6>Italian Pizza</h6>
                                        <p class="mb-0">Data that one wants to keep secure in an effective cyber security strategy.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mb-4 mb-md-0 wow fadeInUp">
                        <div class="ets_card text-center">
                            <div class="ets_card_child">
                                <div class="ets_card_child_two">
                                    <div class="ets_card_child_three">
                                        <div class="ets_icon_wrapper">
                                            <div class="ets_service_icon">
                                                <i class="fas fa-carrot"></i>
                                            </div>
                                        </div>
                                        <h6>Glow Cheese</h6>
                                        <p class="mb-0">Ensure the security of wireless networks to prevent unauthorized access.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow fadeInUp">
                        <div class="ets_card text-center">
                            <div class="ets_card_child">
                                <div class="ets_card_child_two">
                                    <div class="ets_card_child_three">
                                        <div class="ets_icon_wrapper">
                                            <div class="ets_service_icon">
                                                <i class="fas fa-apple-alt"></i>
                                            </div>
                                        </div>
                                        <h6>Sllice Beef</h6>
                                        <p class="mb-0">Provide expert advice and tailored to one of the best organization's needs.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Services Section End -->

        <div class="ets_counter_choose_bg">
            <!-- Counter Section Start -->
            <section class="ets_counter_wrapper">
                <div class="container">
                    <div class="ets_border_bg">
                        <div class="ets_count_wrapper">
                            <div class="row">
                                <div class="col-6 col-md-3 text-center mb-4 mb-md-0 wow fadeInUp">
                                    <h1><span class="count">42</span>+</h1>
                                    <h6>Professional Chefs</h6>
                                </div>
                                <div class="col-6 col-md-3 text-center wow fadeInUp">
                                    <h1><span class="count">320</span>+</h1>
                                    <h6>Items Of Food</h6>
                                </div>
                                <div class="col-6 col-md-3 text-center wow fadeInUp">
                                    <h1><span class="count">30</span>+</h1>
                                    <h6>Years Of Experienced</h6>
                                </div>
                                <div class="col-6 col-md-3 text-center wow fadeInUp">
                                    <h1><span class="count">220K</span>+</h1>
                                    <h6>Happy Customers</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Counter Section End -->

            <!-- Why Choose Me Section Start -->
            <section class="ets_choose_me_wrapper">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12 col-lg-6 order-1 order-lg-0 wow fadeInLeft">
                            <h2>Exta ordinary taste And Experienced</h2>
                            <p class="mb-lg-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque diam pellentesque bibendum non dui volutpat fringilla bibendum. Urna, elit augue urna, vitae feugiat pretium donec id elementum. Ultrices mattis sed vitae mus risus. Lacus nisi, et ac dapibus sit eu velit in consequat.</p>
                            
                            <p class="mb-4">Multiple layers of security are dispersed the computers, networks, programs, or  data that one wants to keep secure.</p>
                            <ul class="ps-0">
                                <li class="d-flex">
                                    <div>
                                        <i class="fas fa-medal ets_icon"></i>
                                    </div>
                                    <div>
                                        <h6>Fast Food</h6>
                                        <p>For business to have a successful defence against cyber attacks, the people, processes, and technology.</p>
                                    </div>
                                </li>
                                <li class="d-flex">
                                    <div>
                                        <i class="fas fa-microchip ets_icon"></i>
                                    </div>
                                    <div>
                                        <h6>Lunch</h6>
                                        <p>By automating interconnections across a few Cisco is a security products for the cyber security.</p>
                                    </div>
                                </li>
                                <li class="d-flex">
                                    <div>
                                        <i class="fas fa-headset ets_icon"></i>
                                    </div>
                                    <div>
                                        <h6>Dinner</h6>
                                        <p class="mb-0">Unified threat management system may the speed is up crucial security operations tasks Like detection, investigation.</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-12 col-lg-6 d-flex justify-content-center justify-content-lg-end order-0 order-lg-1 mb-4 mb-md-5 mb-lg-0 wow fadeInRight">
                            <div class="ets_img_wrapper position-relative">
                                <img src="./assets/images/why_choose_me_img.png" class="w-100 h-100" alt="Why Choose Me Image">
                                <div class="ets_img_overlay"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Why Choose Me Section End -->
        </div>

        <div class="ets_cta_project_bg">
            <!-- Call To Ation Section Start -->
            <section class="ets_c2a_wrapper">
                <div class="container">
                    <div class="ets_border_bg">
                        <div class="ets_c2a_card text-center">
                            <div class="row">
                                <div class="col-md-12 col-lg-10 offset-lg-1 wow fadeInUp">
                                    <h2>privacy is a human right and it belongs to you</h2>
                                    <p>Your Website, Web Servers, And Web Apps Are Protected By The Complete And Tested Solution Suites Offered By Csume, The World Leader In Automotive Cyber Security. Shield Leverages Shield Threat</p>
                                    <a href="#contact" class="btn">Get started</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Call To Ation Section End -->

            <!-- Project Section Start -->
            <section class="ets_project_wrapper" id="project">
                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-lg-8 col-xl-6 offset-md-1 offset-lg-2 offset-xl-3 wow fadeInUp">
                            <h2 class="text-center">Issues with recent fixes</h2>
                            <p class="text-center">I'm Working On A Variety Of Technologies Right Now, Including Web 3.0, Blockchain Technology, Cybersecurity, And Cryptography.</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-lg-4 mb-4 mb-lg-0 wow fadeInLeft">
                            <div class="ets_img_wrapper ets_large_img position-relative w-100">
                                <img src="./assets/images/portfolio_one.jpg" class="w-100 h-100" alt="Project Image">
                                <div class="ets_overlay"></div>
                                <div class="ets_card">
                                    <div class="ets_card_child h-100">
                                        <div class="ets_card_child_two h-100">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-lg-8">
                            <div class="row mb-4">
                                <div class="col-md-6 col-lg-6 col-xl-7 mb-4 mb-md-0 wow fadeInDown">
                                    <div class="ets_img_wrapper ets_small_img position-relative w-100">
                                        <img src="./assets/images/portfolio_two.jpg" class="w-100 h-100" alt="Project Image">
                                        <div class="ets_overlay"></div>
                                        <div class="ets_card">
                                            <div class="ets_card_child h-100">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-5 wow fadeInDown">
                                    <div class="ets_img_wrapper ets_small_img position-relative w-100">
                                        <img src="./assets/images/portfolio_three.jpg" class="w-100 h-100" alt="Project Image">
                                        <div class="ets_overlay"></div>
                                        <div class="ets_card">
                                            <div class="ets_card_child h-100">
                                                <div class="ets_card_child_two h-100">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 col-lg-6 col-xl-5 mb-4 mb-md-0 wow fadeInUp">
                                    <div class="ets_img_wrapper ets_small_img position-relative w-100">
                                        <img src="./assets/images/portfolio_four.jpg" class="w-100 h-100" alt="Project Image">
                                        <div class="ets_overlay"></div>
                                        <div class="ets_card">
                                            <div class="ets_card_child h-100">
                                                <div class="ets_card_child_two h-100">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-7 wow fadeInUp">
                                    <div class="ets_img_wrapper ets_small_img position-relative w-100">
                                        <img src="./assets/images/portfolio_five.jpg" class="w-100 h-100" alt="Project Image">
                                        <div class="ets_overlay"></div>
                                        <div class="ets_card">
                                            <div class="ets_card_child h-100">
                                                <div class="ets_card_child_two h-100">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Project Section End -->
        </div>

        <div class="ets_partner_testimonial_bg">
            <!-- Partner Section Start -->
            <section class="ets_partner_wrapper">
                <div class="container">
                    <div class="ets_border_bg">
                        <div class="ets_partner_box">
                            <div class="row">
                                <div class="col-lg-10 col-xl-8 offset-lg-1 offset-xl-2 text-center wow fadeInDown">
                                    <h2>companies I have work with</h2>
                                    <p class="px-0 px-md-5 mb-4 mb-xl-5">I'm An Cyber Security Specialist With Experience In A Variety Of Related Fields, Including Network Security, Vulnerability Management, Intrusion Detection.</p>
                                </div>
                            </div>
                            <div class="row ets_partner_slider wow fadeInUp">
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_one.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_two.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_three.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_four.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_five.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_six.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="ets_card text-center">
                                        <div class="ets_card_child">
                                            <div class="ets_card_child_two">
                                                <div class="ets_card_child_three">
                                                    <img src="./assets/images/partner_six.png" alt="Partner Image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Partner Section End -->

            <!-- Testimonial Section Start -->
            <section class="ets_testimonial_wrapper">
                <div class="container">
                    <h2 class="text-center">What Our Customer says</h2>
                    <div class="row">
                        <div class=" col-md-12 col-lg-10 offset-md-0 offset-lg-1">
                            <div class="row ets_testimonial_slider">
                                <div class="col-10 mx-auto text-center">
                                    <h4 class="px-4">Tanahair is the friendliest and most efficient company I have ever used. The whole thing takes time to introduce the product and as a result puts forward only the best opportunities that really suit you. they help from start to finish to create a great product identity for your company</h4>
                                    <h6>Shalima Hayden</h6>
                                    <p class="mb-0">Product Designer</p>
                                </div>
                                <div class="col-10 mx-auto text-center">
                                    <h4 class="px-4">Iusto, ea consequuntur consequatur magnam possimus in fuga? Repudiandae quis praesentium sapiente exercitationem odit, quasi inventore eveniet. Cupiditate, quis! Incidunt harum, odio hic, tempore laboriosam impedit nostrum natus voluptatem nam reiciendis officiis.</h4>
                                    <h6>Shalima Hayden</h6>
                                    <p class="mb-0">Product Designer</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Testimonial Section End -->
        </div>

        <!-- Contact Section Start -->
        <section class="ets_contact_wrapper" id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-lg-6 offset-md-1 offset-lg-3 text-center wow fadeInDown">
                        <h2>Get in touch with me</h2>
                        <p class="px-0 px-md-5">I'm an Cyber Security specialist with experience in a variety of related fields, including network security.</p>
                    </div>
                </div>
                <div class="row wow fadeInUp">
                    <div class="col-md-10 col-lg-8 offset-md-1 offset-lg-2">
                        <form class="row needs-validation" novalidate>
                            <div class="col-md-6">
                                <label for="validationCustomFirstName" class="form-label mb-3">First Name</label>
                                <input type="text" class="form-control" id="validationCustomFirstName" autocomplete="off" placeholder="John" required>
                            </div>
                            <div class="col-md-6">
                                <label for="validationCustomLastName" class="form-label mb-3">Last Name</label>
                                <input type="text" class="form-control" id="validationCustomLastName" autocomplete="off" placeholder="Doe" required>
                            </div>
                            <div class="col-md-12">
                                <label for="validationCustomEmail" class="form-label mb-3">Email Address</label>
                                <div class="input-group has-validation">
                                    <input type="email" class="form-control" id="validationCustomEmail" autocomplete="on" placeholder="you@company.com" required>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label for="validationCustomMessage" class="form-label mb-3">Describe about your problem</label>
                                <textarea class="form-control" rows="5" id="validationCustomMessage" placeholder="Write a brief message..." required></textarea>
                            </div>
                            <div class="col-12 text-center">
                                <button class="btn" type="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Section End -->

        <!-- Footer Section Start -->
        <footer class="ets_footer_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-4 mb-4 mb-md-0 wow fadeInLeft">
                        <div class="ets_footer_card">
                            <a href="./index.html"><img src="./assets/images/logo.svg" alt="Footer Logo"></a>
                            <p class="mb-0">I began my work as an engineers freelancer before taking the position of head.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 wow fadeInUp">
                        <div class="ets_footer_card">
                            <h3>Useful links</h3>
                            <div class="row">
                                <div class="col-6">
                                    <ul class="mb-0">
                                        <li class="mb-2 mb-xl-3">
                                            <a href="#about">About Me</a>
                                        </li>
                                        <li>
                                            <a href="#services">Menu</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-6">
                                    <ul class="mb-0">
                                        <li class="mb-3">
                                            <a href="#project">Project</a>
                                        </li>
                                        <li>
                                            <a href="#contact">Contact me</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-4 mt-4 mt-lg-0 wow fadeInRight">
                        <div class="ets_footer_card">
                            <h3>Get in touch</h3>
                            <form class="needs-validation" novalidate>
                                <div class="input-group">
                                    <input type="email" class="form-control" placeholder="Email" aria-describedby="newsletter_btn" autocomplete="on" required>
                                    <button class="btn" type="submit" id="newsletter_btn">drive in</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Section End -->
        <!-- Copy Right Section Start -->
        <div class="ets_copy_right_wrapper">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-3 mb-md-0">
                        <p class="mb-0 text-center text-md-start">&copy;2024 <a href="#" target="_blank">EasyToSearch</a>. All Right Reserved</p>
                    </div>
                    <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                        <ul class="list-group list-group-horizontal">
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-f ets_icon"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-twitter ets_icon"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-linkedin-in ets_icon"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram ets_icon"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Copy Right Section End -->
        
        <!-- Scroll Button Start -->
        <div id="scrollBtn">
            <a href="#">
                <i class="fas fa-chevron-up"></i>
            </a>
        </div>
        <!-- Scroll Button  End -->
    </main>
    
    


    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- WOW Animation JS -->
    <script src="./lib/WOW-master/dist/wow.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>

